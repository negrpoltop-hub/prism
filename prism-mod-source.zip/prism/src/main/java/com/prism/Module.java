package com.prism;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public enum Category {
        VISUALS("Visuals"), HUD("HUD"), CLIENT("Client");
        public final String title;
        Category(String t) { title = t; }
    }

    public final String name;
    public final Category category;
    public boolean enabled;
    public final List<Setting> settings = new ArrayList<>();

    protected Module(String name, Category category, boolean enabled) {
        this.name = name; this.category = category; this.enabled = enabled;
    }

    protected <T extends Setting> T add(T s) { settings.add(s); return s; }

    public void toggle() {
        enabled = !enabled;
        Modules.NOTIFY.push(name + (enabled ? " включён" : " выключен"), enabled);
    }

    public void onTick(MinecraftClient mc) {}
    public void onRender3D(MinecraftClient mc, MatrixStack ms, VertexConsumer vc, Vec3d cam, float td) {}
    public void onHud(DrawContext ctx, MinecraftClient mc) {}
}
