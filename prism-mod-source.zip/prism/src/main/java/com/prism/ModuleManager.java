package com.prism;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
    public static final List<Module> ALL = new ArrayList<>();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("prism.json");

    public static void init() {
        ALL.add(Modules.THEME);
        ALL.add(Modules.HITBOXES);
        ALL.add(Modules.TARGET_RENDER);
        ALL.add(Modules.JUMP_CIRCLES);
        ALL.add(Modules.TRAILS);
        ALL.add(Modules.WATERMARK);
        ALL.add(Modules.TARGET_HUD);
        ALL.add(Modules.MODULES_LIST);
        ALL.add(Modules.NOTIFY);
        load();
    }

    public static List<Module> of(Module.Category c) {
        List<Module> l = new ArrayList<>();
        for (Module m : ALL) if (m.category == c) l.add(m);
        return l;
    }

    public static void tick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) return;
        Targets.tick(mc);
        for (Module m : ALL) if (m.enabled) m.onTick(mc);
    }

    public static void render3D(MinecraftClient mc, MatrixStack ms, VertexConsumer vc, Vec3d cam, float td) {
        for (Module m : ALL) if (m.enabled) m.onRender3D(mc, ms, vc, cam, td);
    }

    public static void hud(net.minecraft.client.gui.DrawContext ctx, MinecraftClient mc) {
        if (mc.player == null || mc.options.hudHidden) return;
        for (Module m : ALL) if (m.enabled) m.onHud(ctx, mc);
    }

    public static void save() {
        try {
            JsonObject root = new JsonObject();
            for (Module m : ALL) {
                JsonObject o = new JsonObject();
                o.addProperty("enabled", m.enabled);
                for (Setting s : m.settings) s.save(o);
                root.add(m.name, o);
            }
            Files.writeString(FILE, GSON.toJson(root));
        } catch (Exception ignored) {}
    }

    private static void load() {
        try {
            if (!Files.exists(FILE)) return;
            JsonObject root = JsonParser.parseString(Files.readString(FILE)).getAsJsonObject();
            for (Module m : ALL) {
                if (!root.has(m.name)) continue;
                JsonObject o = root.getAsJsonObject(m.name);
                if (o.has("enabled")) m.enabled = o.get("enabled").getAsBoolean();
                for (Setting s : m.settings) s.load(o);
            }
        } catch (Exception ignored) {}
    }
}
