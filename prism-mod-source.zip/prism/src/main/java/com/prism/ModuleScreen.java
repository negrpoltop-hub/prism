package com.prism;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;

/** Настройки одного модуля: переключатели, ползунки, цвет (R/G/B) и RGB-режим со скоростью. */
public class ModuleScreen extends Screen {
    private final Module module;
    private final Screen parent;
    private final Map<Integer, Setting.Col> swatches = new LinkedHashMap<>();
    private int px, py, pw, ph, x0, y0, cw = 140, gap = 16, perCol = 6;

    public ModuleScreen(Module m, Screen parent) {
        super(Text.literal(m.name));
        this.module = m; this.parent = parent;
    }

    @Override
    protected void init() {
        swatches.clear();
        List<BiFunction<Integer, Integer, ClickableWidget>> items = new ArrayList<>();
        for (Setting s : module.settings) {
            if (s instanceof Setting.Bool b) {
                items.add((x, y) -> ButtonWidget.builder(W.onOff(b.name, b.value), btn -> {
                    b.value = !b.value; btn.setMessage(W.onOff(b.name, b.value));
                }).dimensions(x, y, cw, 20).build());
            } else if (s instanceof Setting.Num n) {
                items.add((x, y) -> new W.Slider(x, y, cw, n.name, n.min, n.max, n.step, n.value, v -> n.value = v));
            } else if (s instanceof Setting.Col c) {
                swatches.put(items.size(), c);
                String[] ch = {"R", "G", "B"};
                for (int i = 0; i < 3; i++) {
                    final int sh = 16 - i * 8; final String label = c.name + " " + ch[i];
                    items.add((x, y) -> new W.Slider(x, y, cw, label, 0, 255, 1, (c.rgb >> sh) & 255,
                            v -> c.rgb = (c.rgb & ~(255 << sh)) | ((int) v << sh)));
                }
                items.add((x, y) -> ButtonWidget.builder(W.onOff("RGB mode", c.rainbow), btn -> {
                    c.rainbow = !c.rainbow; btn.setMessage(W.onOff("RGB mode", c.rainbow));
                }).dimensions(x, y, cw, 20).build());
                items.add((x, y) -> new W.Slider(x, y, cw, "RGB cycle (s)", 0.5, 10, 0.5, c.speed, v -> c.speed = v));
            }
        }
        int cols = Math.max(1, (items.size() + perCol - 1) / perCol);
        int rows = Math.min(perCol, items.size());
        int total = cols * cw + (cols - 1) * gap + 14;
        pw = total + 24; ph = rows * 22 + 90;
        px = width / 2 - pw / 2; py = height / 2 - ph / 2;
        x0 = px + 12; y0 = py + 34;
        for (int i = 0; i < items.size(); i++)
            addDrawableChild(items.get(i).apply(x0 + (i / perCol) * (cw + gap + 14), y0 + (i % perCol) * 22));
        addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b -> close())
                .dimensions(width / 2 - 60, y0 + rows * 22 + 8, 120, 20).build());
    }

    @Override
    public void renderBackground(DrawContext c, int mx, int my, float d) {
        super.renderBackground(c, mx, my, d);
        RenderUtil.panel(c, px - 1, py - 1, pw + 2, ph + 2, 0xFF8B5CF6);
        RenderUtil.panel(c, px, py, pw, ph, 0xF00D0620);
        c.drawTextWithShadow(textRenderer, module.name, px + 12, py + 12, 0xFFA78BFA);
    }

    @Override
    public void render(DrawContext c, int mx, int my, float d) {
        super.render(c, mx, my, d);
        for (Map.Entry<Integer, Setting.Col> e : swatches.entrySet()) {
            int i = e.getKey();
            int x = x0 + (i / perCol) * (cw + gap + 14) + cw + 3, y = y0 + (i % perCol) * 22;
            c.fill(x, y, x + 10, y + 20, 0xFF000000 | e.getValue().get());
        }
    }

    @Override
    public void close() { ModuleManager.save(); client.setScreen(parent); }
}
