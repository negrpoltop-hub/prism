package com.prism;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.List;

/** Главное меню: вкладки категорий, включение модулей, переход к настройкам. Ctrl+Shift+Y. */
public class PrismScreen extends Screen {
    private static Module.Category cat = Module.Category.VISUALS;
    private int px, py, pw = 280, ph;

    public PrismScreen() { super(Text.literal("Prism")); }

    @Override
    protected void init() {
        List<Module> mods = ModuleManager.of(cat);
        ph = 70 + Math.max(mods.size(), 3) * 24;
        px = width / 2 - pw / 2; py = height / 2 - ph / 2;

        Module.Category[] cats = Module.Category.values();
        int tw = (pw - 16) / cats.length;
        for (int i = 0; i < cats.length; i++) {
            Module.Category c = cats[i];
            addDrawableChild(ButtonWidget.builder(
                    Text.literal(c.title).styled(s -> s.withColor(c == cat ? 0xA78BFA : 0x9CA3AF).withBold(c == cat)),
                    b -> { cat = c; clearAndInit(); }
            ).dimensions(px + 8 + i * tw, py + 26, tw - 2, 20).build());
        }

        int y = py + 54;
        for (Module m : mods) {
            addDrawableChild(ButtonWidget.builder(W.onOff(m.name, m.enabled), b -> {
                m.toggle(); b.setMessage(W.onOff(m.name, m.enabled));
            }).dimensions(px + 8, y, pw - 76, 20).build());
            if (!m.settings.isEmpty()) {
                addDrawableChild(ButtonWidget.builder(Text.literal("Config"),
                        b -> client.setScreen(new ModuleScreen(m, this))
                ).dimensions(px + pw - 64, y, 56, 20).build());
            }
            y += 24;
        }
    }

    @Override
    public void renderBackground(DrawContext c, int mx, int my, float d) {
        super.renderBackground(c, mx, my, d);
        RenderUtil.panel(c, px - 1, py - 1, pw + 2, ph + 2, 0xFF8B5CF6);
        RenderUtil.panel(c, px, py, pw, ph, 0xF00D0620);
        c.drawTextWithShadow(textRenderer, "PRISM", px + 10, py + 9, 0xFFA78BFA);
        String hint = "Ctrl+Shift+Y";
        c.drawTextWithShadow(textRenderer, hint, px + pw - 10 - textRenderer.getWidth(hint), py + 9, 0xFF6B5B95);
    }

    @Override
    public void close() {
        ModuleManager.save();
        client.setScreen(null);
    }
}
